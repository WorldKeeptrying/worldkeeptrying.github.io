import os

print("________爱丽丝梦幻花园 核心 _______")
#时刻更改目录权限为一律开放
os.system("chmod 777 /var/www/html/blog/wp-content/")
print("\n 重启Apache2 \n 关闭Apache2(这样就不会占用80端口) \n 重启MariaDB \n \n \n")
#print("ctrl A D 后台运行 \n 0.打开aria 6800端口并挂住 \n 1.更改 aria.conf \n 2.恢复aria.conf文件的默认配置\n 3.刷新 \n 9.关闭aria 6800端口(WEBUI将一律失效)")
menu = int( input("选项：") )
if menu == 1:
    os.system('systemctl restart apache2')
    print("已重启")
elif menu == 2:
    os.system("systemctl stop apache2")
    print("已关闭，80端口已开放")
elif menu == 3:
    os.system("systemctl restart mysql")
    print("已重启 (极其舒适←_←)")