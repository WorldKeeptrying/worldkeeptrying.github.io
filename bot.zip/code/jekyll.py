import os

os.system("apt-get install nano vim jekyll ")
print("......   jekyll 核心   ......")
print("确认jekyll文章目录位于/var/www/html/blog2/post")
print("写作要选择另存为，否则会影响模板本身。")
print("0.刷新整个网站(生成网站)")
print("1.从模板开始写文章(使用nano)\n2.从模板开始写文章(使用vim)\n3.立即上线(当前端口是 8080)\n4.立即下线(结束jekyll进程)\n5.误改了模板或删除了模板，恢复它 \n \n \n")
print("  使用nano时，ctrl X 保存时输入新文件名 \n  使用vim时 :w 新文件名 使用另存为")

menu = int(input("选一个喜欢的: "))
if menu == 0:
    os.system('cd ~/wiki && jekyll build')
    print("文章已经存储")
elif menu == 1:
    print("开始写作")
    os.system('cd ~/wiki && nano -i 2020-01-01.md')
elif menu == 2:
    print("开始写作，使用vim编辑器")
    os.system('cd ~/wiki && vim 2020-01-01.md')
elif menu == 3:
    print("网站已上线")
    os.system('cd ~/wiki && jekyll serve -H 0.0.0.0 -P 8080 & ')
elif menu == 5:
    os.system("cd ~/wiki && cp ~/code/backup/2020-01-01-.md ~/wiki")
elif menu == 4:
    os.system("screen -S jekyll x -quit")
    print("已经下线")
