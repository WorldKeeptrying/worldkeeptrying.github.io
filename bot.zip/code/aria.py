import os

print("________Aria2 核心 _______")
os.system("apt-get install screen")
print("ctrl A D 后台运行 \n 0.打开aria 6800端口并挂住 \n 1.更改 aria.conf \n 2.恢复aria.conf文件的默认配置\n 3.刷新 \n 9.关闭aria 6800端口(WEBUI将一律失效)")
menu = int( input("选项：") )
if menu == 1:
    os.system('nano ~/aria/aria.conf')
    print("已更改")
    #bash shadowsocks-go.sh
elif menu == 0:
    os.system('screen -S aria2 aria2c --conf-path=/root/aria/aria2.conf')
    print("可以使用空投窗口了。空投地址为io或域名 :6800，如果使用AriaNG，直接访问主站地址。")
elif menu == 2:
    os.system("cp -f ~/code/backup/aria2.conf /root/aria2/")
    print("OK")
elif menu == 3:
    print("ok")
elif menu == 9:
    os.system("screen -S aria2 -X quit")
