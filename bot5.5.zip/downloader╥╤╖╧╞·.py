import os

print("_____下载器核心_____\n0.移动下载的文件至 Apache /var/www/html/myfile/ 文件夹\n1.打开下载器（位于6800端口）\n2.关闭下载器(空出6800端口）\n3.编辑aria2 config配置\n4.恢复初始配置（会清空下载记录）")
menu = int( input("选项：") )
if menu == 0:
    os.system('mv ~/root/down/* /var/www/html/myfile')
    print("所有文件已上线Apache")
elif menu == 1:
    os.system('cd ~/code/ && apt install aria2c && aria2c -c ~/code/aria2.conf')
    print("OK  运行在6800端口")
elif menu == 2:
    os.system('kill -9 aria2')
    print("OK  已经下线")
elif menu == 3:
    os.system('nano ~/code/aria2.conf')
    print("OK  已经保存")
elif menu == 4:
    
