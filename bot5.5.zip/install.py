import os

print("应用商店 5.5")
zsh = int( input("【1/15】 入门必备 安装 OhMyZSH \n\n\n 输入 1 安装 或者 2 跳过 __") )
if zsh == 1:
    print("运行")
    os.system("wget https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh && bash install.sh")
else:
    print("跳过\n\n\n")
aria = int( input("【2/15】安装Aria2 远程空投  \n  -->可以选择WebUI 或 AriaNG 或者一起要了\n \n\n输入 1 安装 或者 2 跳过 __") )
if aria == 1:
    os.system("apt update && apt-get install aria2 apache2 -y")
    os.system("cd ~/code && git clone https://github.com/ziahamza/webui-aria2")
    os.system("cd ~/code && wget https://github.com/mayswind/AriaNg/releases/download/1.2.1/AriaNg-1.2.1-AllInOne.zip")
    os.system("mkdir /var/www/html/down")
    os.system("mkdir /var/www/html/ariang")
    os.system("cd ~/webui-aria2 && cp -R docs/* /var/www/html/down")
    os.system("cd ~/code/backup/ariang && unzip -q AriaNg-1.2.1-AllInOne.zip")
    os.system("cd ~/code/backup/ariang && cp index.html /var/www/html/ariang/")
    print("在 Aria2核心  上线它。（Ctrl A D 挂到后台运行）\n AriaWebUI已安装 \n AriaNG已安装")

else:
    print("跳过\n\n\n")
room = int( input("【3/15】爱丽丝的核心房间 \n  -->要用apache2 和 MariaDB驱动\n\n\n 输入 1 安装 或者 2 跳过 __") )
if room == 1:
    os.system("apt update && apt-get install apache2 mariadb php5 libapache-mod-php -y")
    os.system("cd /var/www/html && wget https://cn.wordpress.org/latest-zh_CN.zip")
    os.system("cd /var/www/html && unzip -q latest-zh_CN.zip && mv wordpress blog")
    os.system("cat ~/code/reload.html > /var/www/html/index.html")
#这些是插件
    os.system("cd /var/www/html/ && wget https://downloads.wordpress.org/plugin/classic-editor.1.6.zip")
    os.system("cd /var/www/html/ && wget https://downloads.wordpress.org/plugin/duplicator.1.4.0.zip")
    os.system("cd /var/www/html/ && wget https://downloads.wordpress.org/plugin/hermit.zip")
    os.system("cd /var/www/html/ && wget https://downloads.wordpress.org/plugin/all-in-one-video-gallery.2.4.4.zip")
    os.system("cp classic-editor.1.6.zip /var/www/html/blog/-wp-content/plugins/")
    os.system("cp duplicator.1.4.0.zip /var/www/html/blog/-wp-content/plugins/")
    os.system("cp hermit.zip /var/www/html/blog/-wp-content/plugins/")
    os.system("cp all-in-one-video-gallery.2.4.4.zip /var/www/html/blog/-wp-content/plugins/")
    os.system("cd /var/www/html/blog/-wp-content/plugins/ && unzip -q classic-editor.1.6.zip")
    os.system("cd /var/www/html/blog/-wp-content/plugins/ && unzip -q duplicator.1.4.0.zip")
    os.system("cd /var/www/html/blog/-wp-content/plugins/ && unzip -q hermit.zip")
    os.system("mkdir /var/www/html/blog/wp-content/backups-dup-lite")
    os.system("chmod 777 /var/www/html/blog/wp-content/backups-dup-lite")
    print("在仪表盘启用插件 ")
#这里是主题
    os.system("cd ~/code && git clone https://github.com/censujiang/Mokore")
    os.system("cp -R Mokore /var/www/html/blog/wp-content/themes")
    os.system("git clone https://github.com/baomihua/boxmoe-dove-")
    os.system("cp -R boxmoe-dove- /var/www/html/blog/wp-content/themes")
    print("在仪表盘启用主题")
    print("虚拟百科已经创建，端口80")
    print("在 百科核心 上线它。")
else:
    print("跳过\n\n\n")
blog2 = int( input("【4/15】爱丽丝的站前路牌\n  --> 必不可少的导航页 \n\n\n 输入 1 安装 或者 2 跳过 __") )
if blog2 == 1:
    os.system("apt update && apt-get install jekyll -y")
    os.system("cd /var/www/html && jekyll new blog2")
    print("在Jekyll 核心 上线它 。")
else:
    print("跳过\n\n\n")

ngrok = int( input("【5/15】Ngrok内网穿透 \n  --> 纯净SSH隧道\n\n\n 输入 1 安装 或者 2 跳过 __") )
if ngrok == 1:
    os.system("cd ~/code && wget ")
    os.system("unzip -q")
    os.system("chnod +x ngrok")
    os.system("./ngrok autotoken ")
    print("在 Ngrok 核心 启用它。（Ctrl A D挂到后台运行）")
else:
    print("跳过\n\n\n")
bbr = int( input("【6/15】BBRplus 内核加速\n  -->隧道或为最大赢家！ \n\n\n输入 1 安装 或者 2 跳过 __") )
if bbr == 1:
    os.system("cd ~/code && wget -N https://raw.githubusercontent.com/chiakge/Linux-NetSpeed/master/tcp.sh && chmod +x tcp.sh &&bash tcp.sh")
else:
    print("跳过\n\n\n")
mysql = int( input("【7/15】MariaDB database \n  -->流行的MySQL 分支软件\n\n\n 输入 1 安装 或者 2 跳过 __") )
if mysql == 1:
    os.system('apt update && apt install mariadb-server')
    os.system('echo 使用 CREATE DATABASE wordpress 创建库')
    print("使用 grant all on *.* to 'username'@'%' 分配权限")
    print("使用FLUSH PRIVILEGES 刷新权限")
else:
    print("跳过\n\n\n")
v2ray = int( input("【8/15】V2Fly For V2ray \n  -->高强度加密隧道  \n \n \n 输入 1 安装 或者 2 跳过 __") )
if v2ray == 1:
    os.system("cd ~/code && wget https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh")
    
else:
    print("跳过\n\n\n")
brookok = int ( input("【9/15】BrookOK 一键配置脚本\n\n\n 输入 0 网络安装 1 本地安装 或者 2 跳过 __") )
if brookok == 0:
    os.system("")
elif brookok == 1:
    os.system("bash ~/code/addons/Brook-ok/brook-ok.sh")
else:
    print("跳过\n\n\n")
frp = int ( input("【10/15】frp 内网穿透\n\n\n 输入 0 网络安装 1 本地安装 或者 2 跳过 __") )
if frp == 0:
    os.system("wget ")
elif frp == 1:
    os.system("wget frp.deb")
else:
    print("跳过\n\n\n")
    
    
