import os

print("_____隐藏站_____\n0.打开\n1.关闭\n2.进入控制")
menu = int( input("选项：") )
if menu == 0:
    os.system('docker restart nginx')
if menu == 1:
    os.system('docker restart nginx')
if menu == 2:
    os.system('docker exec -it nginx')
