import os

print("我的枢纽")
print("欢迎爱丽丝来到她的梦幻城堡，如果你是 不断尝试 ，同样欢迎你。这里是枢纽酱~")
print("必须确定此文件的位置是 /root/")
print("0.安装基础工具『使用sudo apt』")
print("1用自己的网盘安装这些\n2用谷歌家的网盘安装这些\n3用github page 部署脚本包（已加密）\n4用lanzou网盘安装这些\n5查看这些工具们的原作者页面\n6将备份包放在用户目录 cd ~ 中 ，选这个安装本地包 \n　20.特殊模式，仅查看或修改所有工具的备份表格，不安装任何软件 ")
print("30.安装 ohmyzsh ")
os.system("mkdir ~/code")

menu = int(input("选一个喜欢的: "))
if menu == 1:
    print("从自己的云上部署脚本包，如果失败，可以试用短网址https://bit.ly/。")
    os.system('cd ~/code && wget http://198.12.105.214:8887/s/Bx9waKadeKWnTDt/download/bot.zip && unzip -q bot.zip')
    os.system("cp ~/code/start.py ~")
elif menu == 0:
    print("使用apt安装必备软件包。部署中。")
    os.system('apt update && apt install curl wget apache2 vim screen')
    os.system("cp ~/code/start.py ~")
elif menu == 2:
    print("枢纽部署中。\n从谷歌云盘部署脚本包。")
    os.system('cd ~/code/ && wget https://drive.google.com/bot.zip && unzip bot.zip')
    os.system("cp ~/code/start.py ~")
elif menu == 4:
    os.system('wget https://lanzoux.com/ && bot_r.zip')
    os.system("cp ~/code/start.py ~")
elif menu == 3:
    print("枢纽部署中。从 Github Page 部署，会使用密码000000来解包。")
    os.system('wget https://worldkeeptrying.github.io/bot.zip && bot_r.zip')
    os.system("cp ~/code/start.py ~")
elif menu == 5:
    os.system("vim ~/code/bot_info.txt")
elif menu == 6:
    os.system("unzip -q ~/bot.zip")
    print("完成。")
elif menu == 30:
    os.system("sh -c '$(wget https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh -O -)'")
    print("zsh加强版已经安装。")
