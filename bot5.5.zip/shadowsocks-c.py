import os

print("_____Shadowsocks___ \n  --> 确认已从应用商店安装Shadowsocks-go")
print("1.打开或重启SS\n2.关闭SS(空出1092端口)\n3.编辑config配置\n4.重装Shadowsocks")
menu = int( input("选项：") )
if menu == 1:
    os.system('/etc/init.d/shadowsocks restart')
    print("已经打开")
elif menu == 2:
    os.system('/etc/init.d/shadowsocks stop')
    print("已经停止，端口已经释放")
elif menu == 3:
    os.system('nano -i /etc/shadowsocks/config.json')
    print("已经保存")
elif menu == 4:
    os.system('bash ~/code/addons/shadowsocks-go.sh')
    print("OK 按照刚才显示的配置进行连接，旧配置已经废弃")
