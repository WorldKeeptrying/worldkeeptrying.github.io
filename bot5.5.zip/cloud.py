import os

print("_____我的NextCloud_____当前端口2082\n1.重启网盘\n2.关闭网盘\n3.进入容器SSH\n4.备份网盘\n5.删除网盘容器(id: cloud)")
menu = int( input("选项：") )
if menu == 1:
    os.system('docker restart cloud')
    print("已更改")
elif menu == 2:
    os.system('docker stop cloud')
    print("已更改")
elif menu == 3:
    os.system('sync')
    print("利用docker ps -a 显示id，利用 docker exec -it (id) 进入容器")
elif menu == 4:
    os.system('python3 ~/code/backup.py')
    print("已备份")
elif menu == 5:
    os.system('sync')
    print("利用docker ps 显示id，利用 docker rm (id) 删除网盘程序")
    
