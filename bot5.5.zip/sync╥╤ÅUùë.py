import os

os.system("mkdir /usr/backups/")
print("_____同步_____\n0.打包所有文件为zip\n1.打包下载器（空投器）所有已下载文件为zip\n2.打包当前版本脚本（code目录）为zip\n3.打开ftp服务（端口21)\n4.关闭ftp服务（释放端口21）")
print("5.创建Docker 快照\n \n \n 所有备份文件的路径： /usr/backups")
menu = int( input("选项：") )
if menu == 1:
    os.system('cd /usr/backups && zip -q download-file.zip /root/down/*')
    print("已打包")
elif menu == 2:
    os.system('cd /usr/backups && zip -q bot-backup.zip /root/down/*')
    print("已打包")
elif menu == 3:
    os.system('apt install vsftpd && systemctl restart vsftpd')
    print("ftp On")
elif menu == 4:
    os.system('apt install vsftpd && systemctl stop vsftpd')
    print("ftp Off")
