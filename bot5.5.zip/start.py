import os

print("________ 中转站 核心 _______   版本: 5.5\n   -->显示应用市场 20")
os.system("sync")
print("\n   1.爱丽丝的虚拟花园\n   2.爱丽丝的站前路牌\n   3.V2ray核心\n   4.brook核心")
print("   5.Shadowsocks核心\n   6.爱丽丝的隐藏站")
print("   7.网盘核心\n   8.新闻核心\n   9.空投器核心\n   10.紧急备份")
print("\n   0.排雷专用，极其舒适")
menu = int( input("选项：") )
if menu == 0:
    os.system('systemctl restart mysql && sync')
    print("OK")
elif menu == 1:
    os.system('python3 ~/code/apache.py')
    print("OK")
elif menu == 2:
    os.system('python3 ~/code/jekyll.py')
    print("OK")
elif menu == 3:
    os.system('python3 ~/code/v2ray.py')
    print("OK")
elif menu == 4:
    os.system('python3 ~/code/brook.py')
    print("OK")
elif menu == 5:
    os.system('python3 ~/code/shadowsocks-c.py')
    print("OK")
elif menu == 6:
    os.system('python3 ~/code/deepsite.py')
elif menu == 7:
    os.system('python3 ~/code/cloud.py')
elif menu == 8:
    os.system('python3 ~/code/news.py')
elif menu == 9:
    os.system('python3 ~/code/downloader.py')
elif menu == 10:
    os.system('python3 ~/code/backup.py')
elif menu == 20:
    os.system("python3 ~/code/install.py")
