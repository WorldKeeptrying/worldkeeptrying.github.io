import os

print("     __...___...___v2ray 核心 ___...__...__")
os.system("v2ctl -v")
print("-->ctrl A D 后台运行 \n 0.打开v2ray并挂住 \n 1.更改 config.json \n 2.恢复默认配置 (就是纯 vmess的配置) \n 3.刷新 \n 9.关闭")
menu = int( input("选项：") )
if menu == 1:
    os.system('nano -i /usr/local/etc/v2ray/config.json')
    print("已更改")
    #bash shadowsocks-go.sh
elif menu == 0:
    os.system('systemctl restart v2ray')
    print("已经开启，在『番茄工具箱』查看二维码或配置。")
elif menu == 2:
    os.system("cp -f ~/code/addons/V2ray/config.json /usr/local/etc/v2ray/")
    print("OK")
elif menu == 3:
    print("ok")
elif menu == 9:
    os.system("systemctl stop v2ray")
