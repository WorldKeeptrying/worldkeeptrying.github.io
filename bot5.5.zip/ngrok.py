import os

print("Ngrok SSH 无视墙")
print("注意，包含爱丽丝本人的密钥，注意")
print("screen使用 ctrl A D 挂在后台运行")
print("0.Ngrok启动并挂到后台运行 ssh端口 22 ")
print("1.安装ngrok(官网下载并解压)\n2.从自己网盘安装ngrok(网盘下载并解压)\n3.修复环境 ")
print("20.关闭ngrok(谨慎点，如果没有番茄，关闭会导致服务器失联)")

menu = int(input("选一个喜欢的: "))
if menu == 1:
    print("安装ngrok(如已安装，会直接覆盖)")
    os.system('wget && unzip && ./ngrok addtoren')
elif menu == 0:
    print("ngrok运行了，ssh地址换成这个，无视墙")
    os.system('cd ~ && screen -S ngrok ./ngrok tcp 22')
elif menu == 2:
    print("从本地安装")
    os.system('unzip')
elif menu == 3:
    print("修复后台运行环境，也就是重装screen。")
    os.system('apt-get install screen')
elif menu == 5:
    os.system("vim bot_info.txt")
elif menu == 6:
    os.system("unzip ~/bot.zip")
    print("完成。")
elif menu == 20:
    os.system("screen -D -r ngrok")
    print("关闭了，如果正通过ngrok使用现在的这个终端，将会直接断开。")
