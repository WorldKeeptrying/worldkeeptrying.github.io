import sys
import os

print("=====              安装器                ———————— ")
print("=====    默认在线安装，输入19切换到本地安装    =====")
#os.system('chmod +x tcp.sh docker.sh ')
print("=====1.安装Shadowsocks-Go         2. 安装docker=====")
print("=====3.安装Nextcloud          4. 恢复 网盘数据 =====")
print("=====5.安装apache和StartNow     6. 安装 bbr加速=====")
print("=====7.国际版docker-ce    8. 使用镜像docker-ce =====")
print("=====9.安装v2ray                10. 番茄二维码 =====")
print("=====11. debian独特的apache2与php安装。        =====")
print("=====12.安装wordpress到公网，并导入数据        =====")
print("=====  (公开版脚本不可导入数据                 =====")
print("=====14.ngrok一键配置(无视墙)   15.shadowsocksR")
print("0.切换源 30.刷新 31.安装bbrplus")
menu = int( input("安装序号：") )
if menu == 1:
    print("安装中。。。")
    os.system('wget https://raw.githubusercontent.com/zyy3096/teddysun-shadowsocks_install/master/shadowsocks-go.sh')
    os.system("chmod +x shadowsocks-go.sh && bash shadowsocks-go.sh")
    #bash shadowsocks-go.sh
elif menu == 2:
    print("安装中。。。")
    os.system('bash docker_bot.sh')
    #sudo apt install docker-ce

elif menu == 3:
    print("安装中。。。")
    os.system('bash docker_nextcloud_bot.sh')
    #docker pull nextcloud:latest
    
elif menu == 4:
    print("安装中。。。")
    os.system('bash backup_cloud_docker_bot.sh')
    #docker pull worldkeeptrying/nextcloud

elif menu == 5:
    print("安装中。。。")
    os.system('bash apache_php_startnow_bot.sh')
    #sudo apt install apache2 php7 apache2_mod_php
    #cp -startnow /var/www/html/
    	
elif menu == 6:
    print("安装中。。。")
    os.system('bash try.sh')
    #bash try.sh
elif menu == 7:
    print("安装中。。。")
    os.system('bash wget docker_installer.sh')
elif menu == 8:
    print("安装中。。。")
    os.system('bash aliyun_docker_installer.sh')
elif menu == 9:
    print("安装中。。。")
    os.system('bash install.sh')
    #bash install.sh
elif menu == 10:
    print("按住拷贝")
    print("ssr://MTk4LjEyLjEwNS4yMTQ6NDQzMDpvcmlnaW46YWVzLTI1Ni1jZmI6cGxhaW46Y1hkbGNuUjVkV2svP29iZnNwYXJhbT0mcHJvdG9wYXJhbT0mcmVtYXJrcz01cHlBNWJ5NiZncm91cD0")
    print("vmess://eyJhZGQiOiIxOTguMTIuMTA1LjIxNCIsImFpZCI6IjAiLCJob3N0IjoiIiwiaWQiOiJiODMxMzgxZC02MzI0LTRkNTMtYWQ0Zi04Y2RhNDhiMzA3MTEiLCJuZXQiOiJ0Y3AiLCJwYXRoIjoiIiwicG9ydCI6IjIwODMiLCJwcyI6IuacgOW8uiIsInNuaSI6IiIsInRscyI6IiIsInR5cGUiOiJub25lIiwidiI6IjIifQ==")
elif menu == 11:
    os.system('bash apache2_php_for_debian.sh')
elif menu == 12:
    os.system('bash wordpress_i_bot.sh')
elif menu == 14:
    print("使用 screen -S ngrok 开启新窗口，使用 ./ngrok tcp 22 开启穿透。")
    os.system('bash ngrok_bot.sh')
elif menu == 30:
    os.system("bash reload.sh")
elif menu == 31:
    os.system("wget https://github.com/cx9208/Linux-NetSpeed/raw/master/tcp.sh && chmod +x tcp.sh && ./tcp.sh")
elif menu ==15:
    os.system("wget https://raw.githubusercontent.com/zyy3096/teddysun-shadowsocks_install/master/shadowsocksR.sh")
    os.system("chmod +x shadowsocksR.sh && bash shadowsocksR.sh")
    
