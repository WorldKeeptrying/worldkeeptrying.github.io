import os

print("________Aria2 核心 _______")
#检测是否安装screen
os.system("apt-get install screen -y ")
print("ctrl A D 后台运行 \n 0.打开aria 6800端口并挂住 \n 1.更改 aria.conf \n 2.恢复aria.conf文件的默认配置\n 3.刷新 \n 5.移动下载的文件至 Apache /var/www/html/myfile/ \n 9.关闭aria 6800端口(WEBUI将一律失效)")
menu = int( input("选项：") )
if menu == 1:
#用nano 编辑器 编辑配置
    os.system('nano ~/aria/aria.conf')
    print("已更改")
    #bash shadowsocks-go.sh
elif menu == 0:
#用Screen 启动名称 aria2 的后台服务 然后挂上 aria2 rpc服务 端口6800
    os.system('screen -S aria2 cd ~/aria && aria2c --conf-path=/root/aria/aria2.conf --rpc-secret=000000')
    print("可以使用空投窗口了。空投地址为io或域名 :6800，如果使用AriaNG，直接访问主站地址。")
elif menu == 2:
    os.system("cp -f ~/code/addons/Aria2/aria2.conf /root/aria2/")
    print("OK")
elif menu == 3:
    print("ok")
elif menu == 5:
    os.system('mv ~/root/down/* /var/www/html/myfile')
    print("所有文件已上线Apache")
elif menu == 9:
#使用Screen 的结束指令 -d 停止aria2
    os.system("screen -d aria2")
