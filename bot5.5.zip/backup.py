import os

os.system("mkdir /usr/backups/")
print("_____备份选项_____\n   0.打包/root目录为zip\n   1.打包下载器（空投器）所有已下载文件为zip\n   2.打包当前版本脚本（code目录）为zip\n   3.打开ftp服务（端口21)\n   4.关闭ftp服务（释放端口21）")
print("   5.创建Docker 快照\n \n \n \n \n --> 所有备份文件的路径： /usr/backups")
menu = int( input("选项：") )
if menu == 1:
    os.system('cd /usr/backups && zip -q download-file.zip /root/down/*')
    print("已打包")
elif menu == 2:
    os.system('cd /usr/backups && zip -q bot-backup.zip /root/code/*')
    print("已打包")
elif menu == 3:
    os.system('apt install vsftpd && systemctl restart vsftpd')
    print("ftp On 用任意管理器连接并进入/usr/backups/目录取出备份文件")
elif menu == 4:
    os.system('apt install vsftpd && systemctl stop vsftpd')
    print("ftp Off 已经关闭")
    
